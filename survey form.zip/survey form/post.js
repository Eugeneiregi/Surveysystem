// alert("Hello this the post form")

function myFuction() {
    alert("Your post its on its way to the Survey form")
};